import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'home_config.dart';
import 'widgets/menu_button.dart';

/// ASTORYA Main Menu (port of MainMenu.tsx + MobileCanvas.tsx).
///
/// Renders only the original background image and the four buttons on a
/// uniformly scaled 412 x 917 canvas. Existing navigation is injected via
/// the four optional callbacks (see NAVIGATION_INTEGRATION.md).
///
/// `const HomeScreen()` / `HomeScreen()` still compile, so the existing
/// Splash Screen (`HomeScreen()`) needs no change.
class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    this.onStart,
    this.onInstructions,
    this.onAbout,
    this.onExit,
  });

  /// "Mulai" — should open the existing native AR scanner directly.
  final VoidCallback? onStart;

  /// "Petunjuk" — existing instructions page / placeholder.
  final VoidCallback? onInstructions;

  /// "Tentang" — existing About page / placeholder.
  final VoidCallback? onAbout;

  /// "Keluar" — existing exit behavior. When null, closes the app with
  /// [SystemNavigator.pop] (Android); replace via the callback if the
  /// project already does something different.
  final VoidCallback? onExit;

  VoidCallback? _callbackFor(MenuButtonId id) {
    switch (id) {
      case MenuButtonId.start:
        return onStart;
      case MenuButtonId.instructions:
        return onInstructions;
      case MenuButtonId.about:
        return onAbout;
      case MenuButtonId.exit:
        return onExit ?? () => SystemNavigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: HomeConfig.pageBackdrop,
      body: Center(
        // Uniform scale: min(width / 412, height / 917), centered, no
        // stretching, no scrolling.
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: kHomeDesignWidth,
            height: kHomeDesignHeight,
            child: ClipRect(
              child: Stack(
                clipBehavior: Clip.hardEdge,
                children: [
                  // Original background: object-cover over the full canvas.
                  Positioned.fill(
                    child: ExcludeSemantics(
                      child: Image.asset(
                        HomeConfig.backgroundAsset,
                        fit: BoxFit.cover,
                        filterQuality: FilterQuality.high,
                        gaplessPlayback: true,
                      ),
                    ),
                  ),
                  // The four buttons, absolutely positioned on the canvas.
                  for (final b in HomeConfig.buttons)
                    Positioned(
                      left: b.x,
                      top: b.y,
                      width: b.width,
                      height: b.height,
                      child: MenuButton(
                        config: b,
                        onPressed: _callbackFor(b.id),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
