# Source mapping (React → Flutter)

| React source | Flutter file |
|---|---|
| src/config/menuConfig.ts, index.css (button rules, font-face) | lib/features/home/home_config.dart |
| src/components/MainMenu.tsx + MobileCanvas.tsx | lib/features/home/home_screen.dart |
| src/components/MenuButton.tsx + .astorya-menu-button CSS | lib/features/home/widgets/menu_button.dart |
| src/components/MenuIcons.tsx | lib/features/home/widgets/menu_icon.dart |
| App.tsx (toast feedback) | NOT ported (prototype-only) |

Splash files in the ZIP were ignored.

## Extracted values (all matched the values in your prompt)
- Canvas 412 × 917. Background `backgorund-menu-utama_be8f3b85.png` (1051×2338, object-cover). SHA-256 `be8f3b85144406845e7534d4da482ae15a6408dcb0bc82703100ebf95d3ece14`. Compare with your existing `asset/menu_utama/backgorund-menu-utama.png`; I did not bundle a copy.
- Buttons (w×h @ x,y): Mulai 202×69 @105,327 · Petunjuk 274×69 @69,432 · Tentang 274×69 @69,535 · Keluar 278×69 @67,646.
- Text: 34px, weight 860, `"SOFT" 100, "WONK" 1, "opsz" 36`, #60300D, letter-spacing -0.01em, line-height 1.1, translateY(-1px).
- Icon: 30px, viewBox 28, #60300D, stroke 2.3, gap 14. Per-icon strokes: about "i" 2.35; exit 2.45 (2.3+0.15).
- Button: radius 35, border 1.75 (top #F5C687, sides #E3A95E, bottom #CB8636), gradient #FFE3B8 / #FFD9A1 / #F0BD77 at 0/50/100%.
- Shadows: default / hover / pressed as in menuConfig.ts (kept as three `MenuButtonLook` constants).
- Interaction: 150 ms, cubic-bezier(0.22,1,0.36,1), pressed scale 0.975, hover brightness 1.03, focus outline 2.5px #60300D offset 3px, reduced motion disables transition and scale.

## Differences vs. React
- The font is a static TTF instance (wght 860, opsz 36) rather than a variable font with CSS variation settings. SOFT/WONK were already baked into the source file.
- Flutter has no CSS borders/inset shadows: the border ring, diagonal color joins and inset shadows are drawn in a CustomPainter. The color joins are my reconstruction of CSS corner behavior and may differ by sub-pixel amounts.
- Hover brightness uses a ColorFilter matrix (RGB × 1.03) instead of CSS `filter: brightness`.
- Latin-ext font file was not used: all four labels are plain Latin.
