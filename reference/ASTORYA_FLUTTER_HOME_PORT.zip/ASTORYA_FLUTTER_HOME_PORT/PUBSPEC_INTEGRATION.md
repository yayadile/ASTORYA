# pubspec.yaml — minimum additions

Keep every existing entry. Add the font (new `fonts:` block, or merge into your existing one) and make sure the menu background folder is listed:

```yaml
flutter:
  assets:
    # existing entries stay
    - asset/menu_utama/      # only if not already declared

  fonts:
    - family: FrauncesSuperSoftWonky
      fonts:
        - asset: asset/fonts/Fraunces-Soft-Black.ttf
          weight: 900
```
Copy `asset/fonts/Fraunces-Soft-Black.ttf` into the project. Run `flutter pub get`; a full restart (not hot reload) is needed to pick up the font.
