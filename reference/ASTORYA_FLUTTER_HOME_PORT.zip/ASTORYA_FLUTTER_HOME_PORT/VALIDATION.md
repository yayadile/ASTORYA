# Validation status

## Actually done
- Read menuConfig.ts, MainMenu.tsx, MenuButton.tsx, MenuIcons.tsx, MobileCanvas.tsx, App.tsx, index.css.
- Decoded both WOFF2 files (via fontTools with a Node-brotli shim). Inspected: family "Fraunces SuperSoft Wonky", axes opsz 9–144 and wght 100–900 only (no SOFT/WONK axes: they are baked in), 245 glyphs (latin file), all label letters present.
- Produced `asset/fonts/Fraunces-Soft-Black.ttf`: static instance wght=860, opsz=36, no fvar table, reopened and checked cmap/metrics. Rendered the four labels with Pillow (`font_preview_PIL.png`): thick, soft, rounded.

## NOT done
- Flutter/Dart are not installed here: **no `flutter analyze`, compile or run**. Syntax, null-safety and API use were reviewed by reading only.
- No rendering of the Flutter UI, and no side-by-side comparison with the React app, so visual equivalence (border joins, inset shadows, text baseline, icon geometry) is unverified.
- I did not compare the font with the browser's variable-font rendering; I only confirmed the TTF is valid.
- Your existing background PNG was not compared with the ZIP's (checksum given).

## Run these
```powershell
flutter pub get
flutter analyze
flutter run -d chrome --dart-define=ASTORYA_PREVIEW_HOME=true
flutter run -d chrome
```
Things to eyeball: label vertical centering (line-height/even leading), border color joins at the pill ends, hover brightness, focus ring (Tab key), and that the shadow isn't clipped by ColorFiltered.
