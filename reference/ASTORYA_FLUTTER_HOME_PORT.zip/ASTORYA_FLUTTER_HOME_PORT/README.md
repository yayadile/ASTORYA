# ASTORYA Flutter Main Menu port (patch package)

1. Work on a local branch copy; no Git commands are run by this package.
2. Copy `lib/features/home/` files over the existing ones (back up `home_screen.dart` first and read NAVIGATION_INTEGRATION.md).
3. Copy `asset/fonts/Fraunces-Soft-Black.ttf` into the project and apply PUBSPEC_INTEGRATION.md.
4. Add the full OFL text next to FONT_LICENSE.txt.
5. Compare your `asset/menu_utama/backgorund-menu-utama.png` with the SHA in SOURCE_MAPPING.md; keep yours if it matches.
6. Run the commands in VALIDATION.md and compare against the React preview.

Splash, story, AR modules and plugins are untouched. Nothing here has been compiled or run.
