# Navigation integration

I could not see your repository, so I did not guess AR scanner constructors or routes.

`HomeScreen` keeps a `const HomeScreen({super.key, ...})` constructor, with four *optional* callbacks:
`onStart`, `onInstructions`, `onAbout`, `onExit`. The existing splash call `HomeScreen()` compiles unchanged.

**Before replacing `lib/features/home/home_screen.dart`:** open your current file and find what each of the four buttons does today. If those actions live in the old HomeScreen, move them into the callbacks, e.g. in the splash's `_goHome()` (don't edit the splash unless you want to) or, simpler, inside the new `HomeScreen` by changing `_callbackFor`:

```dart
case MenuButtonId.start:
  return () => Navigator.of(context).push(...your existing scanner route...);
```
(`_callbackFor` would then need `BuildContext`; pass it in as a parameter.)

Notes:
- Mulai must open the scanner directly (no story list); that wiring is yours.
- Keluar defaults to `SystemNavigator.pop()` when `onExit` is null. This is my assumption; override it if your app exits differently.
- If other files import the old `widgets/menu_button.dart`, check them: the class is now `MenuButton({config, onPressed})`.
- `ASTORYA_PREVIEW_HOME=true` handling lives in the untouched splash/main code.
