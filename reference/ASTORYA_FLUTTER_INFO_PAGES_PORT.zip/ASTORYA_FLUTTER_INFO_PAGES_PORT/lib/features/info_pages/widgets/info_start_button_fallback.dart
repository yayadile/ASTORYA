import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import '../info_pages_config.dart';

/// TEMPORARY FALLBACK for the Petunjuk "Mulai" button.
///
/// The production app already has `lib/features/home/widgets/menu_button.dart`
/// and `menu_icon.dart`, which could not be inspected while this port was
/// written. Their constructors are therefore NOT guessed. [PetunjukPage] takes
/// a `startButtonBuilder`; when it is null this fallback is used so the page
/// compiles and previews on its own.
///
/// **Replace it with the existing Home MenuButton** (see
/// NAVIGATION_INTEGRATION.md §3). This class is deliberately named differently
/// from the Home widget so the two never conflict.
///
/// It is a port of `MenuButton.tsx` / `MenuIcons.tsx` ('start' icon) using the
/// values in `menuConfig.ts`.
class InfoStartButtonFallback extends StatefulWidget {
  const InfoStartButtonFallback({
    super.key,
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback onPressed;

  @override
  State<InfoStartButtonFallback> createState() =>
      _InfoStartButtonFallbackState();
}

// ---- menuConfig.ts values -------------------------------------------------
const String _fontFamily = 'FrauncesSuperSoftWonky';
const double _fontSize = 34;
const double _iconSize = 30;
const double _iconSpacing = 14;
const Color _ink = Color(0xFF60300D);
const double _radius = 35;
const double _borderWidth = 1.75;
const double _pressedScale = 0.975;

/// CSS weight 860. If Home registers the font with a specific weight, use the
/// same one here.
const FontWeight _fontWeight = FontWeight.w900;

const List<BoxShadow> _shadowDefault = <BoxShadow>[
  BoxShadow(
    color: Color.fromRGBO(151, 86, 23, 0.22),
    offset: Offset(0, 3),
    blurRadius: 4,
  ),
];
const List<BoxShadow> _shadowHover = <BoxShadow>[
  BoxShadow(
    color: Color.fromRGBO(151, 86, 23, 0.28),
    offset: Offset(0, 4),
    blurRadius: 6,
  ),
];
const List<BoxShadow> _shadowPressed = <BoxShadow>[
  BoxShadow(
    color: Color.fromRGBO(151, 86, 23, 0.18),
    offset: Offset(0, 1.5),
    blurRadius: 2,
  ),
];

/// `filter: brightness(1.03)` on hover.
const List<double> _brightness = <double>[
  1.03, 0, 0, 0, 0, //
  0, 1.03, 0, 0, 0, //
  0, 0, 1.03, 0, 0, //
  0, 0, 0, 1, 0, //
];
const List<double> _identity = <double>[
  1, 0, 0, 0, 0, //
  0, 1, 0, 0, 0, //
  0, 0, 1, 0, 0, //
  0, 0, 0, 1, 0, //
];

class _InfoStartButtonFallbackState extends State<InfoStartButtonFallback> {
  bool _hovered = false;
  bool _pressed = false;

  void _setPressed(bool value) {
    if (_pressed != value) setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final Duration duration = MediaQuery.disableAnimationsOf(context)
        ? Duration.zero
        : InfoPagesConfig.interactionDuration;
    const Curve curve = InfoPagesConfig.interactionCurve;

    final List<BoxShadow> shadows = _pressed
        ? _shadowPressed
        : (_hovered ? _shadowHover : _shadowDefault);

    // Inset highlight / shade, per state (menuConfig.ts buttonStyle.shadow).
    final _Inset inset = _pressed
        ? const _Inset(
            topColor: Color.fromRGBO(255, 245, 224, 0.55),
            topWidth: 1,
            bottomColor: Color.fromRGBO(203, 134, 54, 0.45),
            bottomWidth: 1,
          )
        : (_hovered
            ? const _Inset(
                topColor: Color.fromRGBO(255, 250, 240, 0.8),
                topWidth: 1.5,
                bottomColor: Color.fromRGBO(203, 134, 54, 0.35),
                bottomWidth: 1.5,
              )
            : const _Inset(
                topColor: Color.fromRGBO(255, 248, 234, 0.72),
                topWidth: 1.5,
                bottomColor: Color.fromRGBO(203, 134, 54, 0.35),
                bottomWidth: 1.5,
              ));

    return Semantics(
      button: true,
      label: widget.label,
      onTap: widget.onPressed,
      excludeSemantics: true,
      child: FocusableActionDetector(
        mouseCursor: SystemMouseCursors.click,
        onShowHoverHighlight: (bool v) => setState(() => _hovered = v),
        actions: <Type, Action<Intent>>{
          ActivateIntent: CallbackAction<ActivateIntent>(
            onInvoke: (ActivateIntent intent) {
              widget.onPressed();
              return null;
            },
          ),
        },
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => _setPressed(true),
          onTapUp: (_) => _setPressed(false),
          onTapCancel: () => _setPressed(false),
          onTap: widget.onPressed,
          child: AnimatedScale(
            scale: _pressed ? _pressedScale : 1.0,
            duration: duration,
            curve: curve,
            child: ColorFiltered(
              colorFilter: ColorFilter.matrix(
                _hovered ? _brightness : _identity,
              ),
              child: AnimatedContainer(
                duration: duration,
                curve: curve,
                padding: const EdgeInsets.all(_borderWidth),
                // CSS uses different colours on top / sides / bottom borders.
                // Flutter cannot combine that with a border radius, so the
                // 1.75 px border is a vertical gradient with the same three
                // colours (menuConfig.ts buttonStyle.border).
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(_radius),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[
                      Color(0xFFF5C687),
                      Color(0xFFE3A95E),
                      Color(0xFFCB8636),
                    ],
                    stops: <double>[0, 0.5, 1],
                  ),
                  boxShadow: shadows,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(_radius - _borderWidth),
                  child: CustomPaint(
                    foregroundPainter: _InsetEdgePainter(
                      radius: _radius - _borderWidth,
                      inset: inset,
                    ),
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: <Color>[
                            Color(0xFFFFE3B8),
                            Color(0xFFFFD9A1),
                            Color(0xFFF0BD77),
                          ],
                          stops: <double>[0, 0.5, 1],
                        ),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            const CustomPaint(
                              size: Size.square(_iconSize),
                              painter: _PlayIconPainter(color: _ink),
                            ),
                            const SizedBox(width: _iconSpacing),
                            Transform.translate(
                              offset: const Offset(0, -1),
                              child: Text(
                                widget.label,
                                maxLines: 1,
                                softWrap: false,
                                textScaler: TextScaler.noScaling,
                                style: const TextStyle(
                                  fontFamily: _fontFamily,
                                  fontSize: _fontSize,
                                  fontWeight: _fontWeight,
                                  color: _ink,
                                  letterSpacing: -0.01 * _fontSize,
                                  height: 1.1,
                                  decoration: TextDecoration.none,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

@immutable
class _Inset {
  const _Inset({
    required this.topColor,
    required this.topWidth,
    required this.bottomColor,
    required this.bottomWidth,
  });

  final Color topColor;
  final double topWidth;
  final Color bottomColor;
  final double bottomWidth;

  @override
  bool operator ==(Object other) =>
      other is _Inset &&
      other.topColor == topColor &&
      other.topWidth == topWidth &&
      other.bottomColor == bottomColor &&
      other.bottomWidth == bottomWidth;

  @override
  int get hashCode =>
      Object.hash(topColor, topWidth, bottomColor, bottomWidth);
}

/// Emulates CSS `inset 0 Ypx 0 colour` shadows (Flutter has no inset shadow):
/// the part of the box not covered by the box shifted by the offset.
class _InsetEdgePainter extends CustomPainter {
  const _InsetEdgePainter({required this.radius, required this.inset});

  final double radius;
  final _Inset inset;

  @override
  void paint(Canvas canvas, Size size) {
    final RRect box = RRect.fromRectAndRadius(
      Offset.zero & size,
      Radius.circular(radius),
    );
    canvas.save();
    canvas.clipRRect(box);

    void band(double dy, Color color) {
      final Path crescent = Path.combine(
        PathOperation.difference,
        Path()..addRRect(box),
        Path()..addRRect(box.shift(Offset(0, dy))),
      );
      canvas.drawPath(crescent, Paint()..color = color);
    }

    band(inset.topWidth, inset.topColor);
    band(-inset.bottomWidth, inset.bottomColor);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_InsetEdgePainter oldDelegate) =>
      oldDelegate.radius != radius || oldDelegate.inset != inset;
}

/// 'start' icon from MenuIcons.tsx: outlined circle + solid rounded play
/// triangle. SVG viewBox 28 × 28, rendered at 30 × 30, stroke 2.3.
class _PlayIconPainter extends CustomPainter {
  const _PlayIconPainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 28, size.height / 28);

    canvas.drawCircle(
      const Offset(14, 14),
      11.2,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.3,
    );

    // M11.6 9.85 C11.6 9.18 12.33 8.77 12.91 9.11 L18.95 12.76
    // C19.5 13.09 19.5 13.91 18.95 14.24 L12.91 17.89
    // C12.33 18.23 11.6 17.82 11.6 17.15 V9.85 Z   (translate 0 0.5)
    final Path play = Path()
      ..moveTo(11.6, 9.85)
      ..cubicTo(11.6, 9.18, 12.33, 8.77, 12.91, 9.11)
      ..lineTo(18.95, 12.76)
      ..cubicTo(19.5, 13.09, 19.5, 13.91, 18.95, 14.24)
      ..lineTo(12.91, 17.89)
      ..cubicTo(12.33, 18.23, 11.6, 17.82, 11.6, 17.15)
      ..lineTo(11.6, 9.85)
      ..close();

    canvas.drawPath(
      play.shift(const Offset(0, 0.5)),
      Paint()
        ..color = color
        ..style = PaintingStyle.fill,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_PlayIconPainter oldDelegate) =>
      oldDelegate.color != color;
}
