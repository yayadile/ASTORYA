# Asset mapping

All dimensions were read from the PNGs in the React ZIP.

| React asset | Natural size | Mode | Flutter path (reuse existing) |
|---|---|---|---|
| background_petunjuk_tentang_1bb92e5c.png | 412 × 917 | RGB | `asset/petunjuk&tentang/background_petunjuk_tentang.png` |
| isian_petunjuk_3fae3b9e.png | 941 × 1672 | RGBA | `asset/petunjuk&tentang/isian_petunjuk.png` |
| isian_tentang_692ec87a.png | 3506 × 4381 | RGBA | `asset/petunjuk&tentang/isian_tentang.png` |
| menu_tentang_62df4a4a.png | 3506 × 4381 | RGBA | `asset/petunjuk&tentang/menu_tentang.png` |
| emblem_astoryaa_1b886ef7.png | 1543 × 1928 | RGBA | `asset/splash_screen/emblem_astoryaa.png` |
| wordmark_a87dfef9.png | 1543 × 1928 | RGBA | `asset/splash_screen/wordmark.png` |

**Verify locally** that the existing Flutter files have the same pixel sizes
as above. The crop rectangles are in source pixels, so a differently sized
file would be cropped wrongly. If a size differs, scale `crop` by
`localSize / listedSize` in `info_pages_config.dart`, or copy the file from the ZIP.

No image is duplicated, renamed or modified. The directory name keeps its `&`.

## Crops (source px → canvas px)

| Use | Asset | Crop x,y,w,h | Target x,y,w,h |
|---|---|---|---|
| Emblem | emblem_astoryaa | 32, 732, 1477, 1196 | 154, 115, 104, 84 |
| Wordmark | wordmark | 18, 1605, 1507, 323 | 140, 204, 133, 28.5 |
| Petunjuk title | isian_petunjuk | 151, 289, 638, 101 | 71.5, 243, 269, 42.6 |
| Petunjuk cards | isian_petunjuk | 48, 416, 844, 808 | 28, 296.5, 356, 340.8 |
| Tentang title | menu_tentang | 20, 163, 3470, 458 | 56, 246, 300, 39.6 |
| Tentang panel | isian_tentang | 53, 129, 3411, 2636 | 19.5, 306, 373, 288.2 |

## Memory

`CroppedAsset` passes `cacheWidth` to `Image.asset`, computed from the rendered
size × device pixel ratio × canvas scale (rounded up to a multiple of 128), so
the 3506 × 4381 PNGs are not decoded at full size (~61 MB each). Large PNGs are
decoded at roughly the on-screen resolution.
