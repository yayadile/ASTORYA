# React → Flutter source mapping

| React | Flutter |
|---|---|
| `config/infoPagesConfig.ts` (+ canvas/interaction of `menuConfig.ts`) | `info_pages/info_pages_config.dart` |
| `components/CroppedAsset.tsx` | `info_pages/widgets/cropped_asset.dart` |
| `components/InfoPageShell.tsx` | `info_pages/widgets/info_page_shell.dart` |
| back `<button>` + SVG + `.astorya-back-button` CSS | `info_pages/widgets/info_back_button.dart` |
| `components/MobileCanvas.tsx` (uniform scale, centred) | `LayoutBuilder` + `FittedBox` inside `InfoPageShell` |
| `.astorya-screen-enter` | `info_pages/info_page_route.dart` |
| `components/PetunjukPage.tsx` | `petunjuk/petunjuk_page.dart` |
| `components/TentangPage.tsx` | `tentang/tentang_page.dart` |
| `MenuButton.tsx` / `MenuIcons.tsx` ('start') | **reuse Home's**; fallback in `info_start_button_fallback.dart` |
| `App.tsx` navigation state machine | not ported; see NAVIGATION_INTEGRATION.md |

## Crop maths (CroppedAsset)

Identical to the React code: `scale = target / crop` per axis; the full image is
laid out at `natural × scale`, offset by `-(crop × scale)`, clipped to the target
box (`Positioned` + `Stack(clipBehavior: hardEdge)`). `Positioned` supplies tight
constraints, so the image cannot be shrunk before the crop.

## Differences from the brief

The numerical values in the brief **match** the final React source exactly
(canvas, back button, branding crops, titles, cards, Mulai geometry, footer).
No value had to be overridden. Observations:

1. The React source also supports the **Escape key** as "back". Ported in the shell.
2. The React `h1`/`ol`/`section` `sr-only` content is ported as Flutter
   `Semantics` regions laid over the artwork (heading + one region per row).
3. Footer font is `Georgia` italic with serif fallbacks (as in React). Android
   has no Georgia, so it renders in the platform serif.
4. CSS allows different border colours per side on a rounded button. Flutter
   does not. The fallback Mulai button uses a vertical gradient border
   (#F5C687 → #E3A95E → #CB8636) and emulates the inset shadows with a painter.
   Only the fallback is affected; Home's real button is used in production.
5. `showVersionFooter` is `true` by default on both pages, as in the React source.
