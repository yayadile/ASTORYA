# ASTORYA — Flutter port of Petunjuk & Tentang

Native Flutter/Dart conversion of the final Google AI Studio React pages
(`astorya-—-cinematic-tentang-petunjuk.zip`). Only Petunjuk and Tentang are
ported. Splash, Home, fonts, AR and `pubspec.yaml` are untouched.

## Status (read this first)

| Item | State |
|---|---|
| Source inspection of the React ZIP | Done. Every value below was read from the source. |
| Dart source files | Written and reviewed by hand. |
| `flutter analyze` / compile | **NOT run.** Flutter is not available in the environment that produced this package. |
| Visual test in Chrome / Android | **NOT run.** Must be done locally. |
| Crop rectangles | Checked with an image script (all crops are inside the PNGs; composite shows no leaked old buttons/footer). This validates the numbers, not the Flutter rendering. |
| Existing Home / MenuButton / AR | **Not accessible**, so nothing was edited or guessed. See NAVIGATION_INTEGRATION.md. |

## Contents

```
lib/features/
├── info_pages/
│   ├── info_pages_config.dart          all geometry, colours, text (port of infoPagesConfig.ts)
│   ├── info_page_route.dart            180 ms fade route (port of .astorya-screen-enter)
│   └── widgets/
│       ├── cropped_asset.dart          CroppedAsset (+ InfoCanvasScope)
│       ├── info_page_shell.dart        shell + InfoSemanticsRegion
│       ├── info_back_button.dart       capsule back button + arrow painter
│       └── info_start_button_fallback.dart  temporary Mulai button (replace with Home MenuButton)
├── petunjuk/petunjuk_page.dart
└── tentang/tentang_page.dart
```

Two files go beyond the recommended structure: `info_page_route.dart` (page
fade) and `info_start_button_fallback.dart` (the integration boundary for the
Mulai button; see NAVIGATION_INTEGRATION.md §3).

## Install

1. Copy `lib/features/*` into the project's `lib/features/`.
2. Add one line to `pubspec.yaml` assets (PUBSPEC_INTEGRATION.md).
3. Wire Home buttons (NAVIGATION_INTEGRATION.md).
4. Run the commands in VALIDATION.md.

No new packages. Only Flutter SDK widgets are used (`material.dart` only for `Scaffold`).
