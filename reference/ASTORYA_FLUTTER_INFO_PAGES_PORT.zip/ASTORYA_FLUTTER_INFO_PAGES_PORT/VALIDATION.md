# Validation

## What was verified here (no Flutter SDK available)

* Source values read from the React source and compared with the brief: identical.
* PNG natural sizes confirmed; every crop rectangle lies inside its PNG.
* A composite built from the exact crop/target numbers shows: emblem, wordmark,
  Petunjuk title + 3 cards, Tentang title + panel, with **no** old back button,
  old Mulai Scan button, duplicate logo or duplicate footer inside the crops.
* Manual code review for null safety, const-expression validity, imports and
  Flutter API use (`Color.withValues`, `MediaQuery.*Of`, `TextScaler` need a
  recent Flutter; the project's 3.50 is fine).

## NOT verified (must be run locally)

`flutter analyze`, compilation, Chrome rendering, Android rendering, font weight
of the Mulai label, the `&` asset path on web, safe-area behaviour on notched
phones, TalkBack. Android AR cannot be tested through Chrome.

## Commands

```powershell
flutter pub get
flutter analyze
flutter run -d chrome --dart-define=ASTORYA_PREVIEW_HOME=true
flutter run -d chrome
```

## Checklist

1. Petunjuk opens from Home (180 ms fade).
2. Tentang opens from Home.
3. Both back buttons (and Escape, Android back) return to the existing Home.
4. No Splash replay on back.
5. Petunjuk Mulai triggers the same handler as Home Mulai.
6. Home unchanged. Splash unchanged.
7. No duplicate artwork: one logo, one title, one footer, one Mulai.
8. No missing-image or overflow errors in the console.
9. Layout: 412:917 portrait centred on desktop, no scroll, no stretch; resize the window and confirm proportions stay fixed.
10. Back button: hover shadow, pressed 0.96 scale, Tab focus ring, Enter/Space activate.
11. Compare against the React preview side by side: positions of emblem, wordmark, title, cards, Mulai and `— v1.0.0 —` (y = 794).
12. Enable "reduce motion" / screen reader and check the fade is skipped and the headings, steps and paragraphs are read.

## Known approximations

* Fallback Mulai border uses a vertical gradient rather than per-side CSS colours.
* Fallback Mulai font weight is `w900` (CSS 860). Match Home's weight.
* Footer font differs per platform (Georgia on Windows/macOS, platform serif on Android).
* Semantics regions split the card artwork into equal vertical thirds; the
  artwork rows are near-equal in height, so focus rectangles are approximate.
