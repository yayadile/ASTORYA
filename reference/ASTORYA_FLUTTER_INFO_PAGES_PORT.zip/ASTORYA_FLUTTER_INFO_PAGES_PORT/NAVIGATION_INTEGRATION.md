# Navigation integration

Home source (`home_screen.dart`, `menu_button.dart`, AR route) was **not
available**. No constructor or route has been guessed. Three small edits are
needed in your project.

## 1. Home → Petunjuk / Tentang

In `home_screen.dart`, in the callbacks for the Petunjuk and Tentang buttons
(use your actual callback names):

```dart
import '../info_pages/info_page_route.dart';
import '../petunjuk/petunjuk_page.dart';
import '../tentang/tentang_page.dart';

// Petunjuk button
Navigator.of(context).push(
  InfoPageRoute<void>(
    builder: (_) => PetunjukPage(onStart: /* SAME function Home "Mulai" calls */),
  ),
);

// Tentang button
Navigator.of(context).push(
  InfoPageRoute<void>(builder: (_) => const TentangPage()),
);
```

`push` keeps the existing Home on the stack, so Back (`Navigator.maybePop`),
Escape and Android system back return to that same Home instance. No second
HomeScreen is created and the Splash Screen does not replay.

## 2. Petunjuk "Mulai" = Home "Mulai"

`PetunjukPage.onStart` is **required**. Pass the exact method Home's Mulai
button uses (e.g. `_handleStart`). If that method only works from inside
`HomeScreen`, expose it or pass a closure.

If Home's Mulai currently goes through an intermediate route (e.g. a
`StoryListPage`), that is a discrepancy with the required flow
(Mulai → AR Scanner). It is not changed here; report/fix it separately.

If the AR route should replace the info page instead of stacking on it, do that
inside the callback (e.g. `pushReplacement`). The page itself does nothing but
call `onStart`.

## 3. Use the existing Home MenuButton for "Mulai"

`PetunjukPage` accepts:

```dart
startButtonBuilder: (BuildContext context, InfoStartButtonConfig cfg, VoidCallback onPressed) {
  // Return Home's MenuButton, sized to fill the box it is given.
}
```

The returned widget is placed in a `Positioned` of exactly 202 × 69 at (105, 651).
It must **not** position itself. Label `cfg.label` = "Mulai"; use the same
play icon as Home. Example shape (adapt to the real constructor):

```dart
startButtonBuilder: (context, cfg, onPressed) => MenuButton(
  label: cfg.label,
  /* icon: Home's start icon */
  onPressed: onPressed,
),
```

If the builder is omitted, `InfoStartButtonFallback` is used. It is a faithful
port of `MenuButton.tsx`, but a duplicate, so use it only for previewing and
remove it from the final integration when the builder is wired.

## 4. Back handling

* Back button, Escape key: `onBack ?? Navigator.maybePop`.
* Android system back / predictive back: handled by the Navigator (nothing extra).
* Pass `onBack` only if Home needs custom behaviour.

## 5. Preview flag

`ASTORYA_PREVIEW_HOME=true` is untouched. The pages never read it.

## Flow

```
Splash → Home ─ Mulai ───────────→ existing AR entry
              ├ Petunjuk → PetunjukPage ─ Kembali → Home
              │                         └ Mulai ──→ existing AR entry
              ├ Tentang  → TentangPage  ─ Kembali → Home
              └ Keluar   → existing exit behaviour
```
