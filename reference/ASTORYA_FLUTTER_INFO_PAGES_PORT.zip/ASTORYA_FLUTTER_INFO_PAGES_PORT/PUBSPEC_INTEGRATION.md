# pubspec.yaml integration

Add **one line** to the existing `flutter: assets:` list. Do not add a second
`flutter:` section and do not replace the file.

```yaml
flutter:
  assets:
    # ...existing entries (splash_screen, menu_utama, fonts, AR, audio, video, models) stay...
    - "asset/petunjuk&tentang/"
```

The path is quoted because it contains `&`. The trailing slash registers all
four PNGs in that folder.

The emblem and wordmark come from `asset/splash_screen/`, which is already
registered for the Splash Screen. If it is declared file by file, make sure
`emblem_astoryaa.png` and `wordmark.png` are both listed.

No new dependencies. The font `FrauncesSuperSoftWonky` is already registered
for Home; nothing to add.

After editing: `flutter pub get`, then a full restart (hot reload does not
pick up new assets).

> Risk to check on Chrome: asset URLs containing `&`. Flutter percent-encodes
> asset keys itself and this usually works. If an image 404s on web only,
> rename the folder to `petunjuk_tentang` and update the six paths in
> `info_pages_config.dart` (the folder was not renamed here, as instructed).
