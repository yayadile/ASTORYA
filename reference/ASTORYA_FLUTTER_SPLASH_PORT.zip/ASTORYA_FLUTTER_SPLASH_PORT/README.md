# ASTORYA Flutter splash port (patch package)

Contents: `lib/features/splash/splash_screen.dart`, `splash_config.dart`, the 9 original PNGs under `asset/splash_screen/`, and the three integration notes.

## Verify (run in your project; NOT run by me)
```powershell
flutter pub get
flutter analyze
flutter run -d chrome
flutter run -d chrome --dart-define=ASTORYA_PREVIEW_HOME=true
```

## Status — be aware
- Flutter/Dart were not available in my environment: this code has **not been compiled, analyzed or run**. Visual equivalence is **unverified**; please compare against the React preview.
- Your Flutter repo was not attached, so nothing was modified in it.

## Differences / limitations vs. React
- Easing uses the exact polynomial formulas from `easing.ts` (not `Curves.*`, which differ slightly). A single linear 6 s controller + math replaces per-layer `Interval`s, which keeps the windows exact.
- "Ambient" drift uses elapsed splash time (same as React during playback). Reduced-motion maps to `MediaQuery.disableAnimations`.
- Font: React asks for Plus Jakarta Sans but the project doesn't bundle it, so the browser likely fell back to a system font; Flutter uses the default font. Bundle the font and set `fontFamily` if you want a match.
- The loading bar's inner (inset) shadow is omitted; the outer shadow is kept.
- Animation starts after all 9 images are precached, so a slow first decode delays the start rather than skipping frames.
- Progress is a timed visual, not AR readiness.
- Preview-studio UI (scrubber, layer toggles) is not ported.
