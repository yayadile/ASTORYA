# Asset mapping (React → Flutter)

| # | Role | React file (public/assets/aistudio/) | Flutter file (asset/splash_screen/) |
|---|------|------|------|
| 1 | Background | background_splashscreen_74a51a43.png | background_splashscreen.png |
| 2 | Distant temples | candi_e7c3b3bd.png | candi.png |
| 3 | Wayang watermark | wayang_0a4877e5.png | wayang.png |
| 4 | Upper clouds | awan_depan_atas_3a55b84d.png | awan_depan_atas.png |
| 5 | Middle clouds | awan_depan_bawah_00f7ebde.png | awan_depan_bawah.png |
| 6 | Frontmost clouds | awan_palingdepan_bawah_1523c2b3.png | awan_palingdepan_bawah.png |
| 7 | Rama & Sinta | asset_rama_sinta_48446c5c.png | asset_rama&sinta.png |
| 8 | Emblem | emblem_astoryaa_1b886ef7.png | emblem_astoryaa.png |
| 9 | Wordmark | wordmark_a87dfef9.png | wordmark.png |

Ignored (not used by the splash code): image_de618bae.png (storyboard screenshot), Paste_November_21__2026_-_8_28PM_ead9f90d (a text prompt).

## Do not overwrite blindly
The PNGs in this package are the originals from the ZIP. If your project already has files with these names, compare SHA-256 first
(PowerShell: `Get-FileHash asset\splash_screen\*.png`). Copy only the ones that differ, and only if you accept replacing them.

SHA-256 of the packaged files:

| SHA-256 | File |
|---|---|
| 48446c5c59fc5606936b81aae87f6ba19cb87165cd8feb9199bfd9d59e2f032c | asset_rama&sinta.png |
| 3a55b84d6cd6ec56a9e0302053bf173fdaf8723d4b7c21aaf6d31f36e3c1d074 | awan_depan_atas.png |
| 00f7ebde861b9be903d45593f4c2d5077ec3d3559c88eba8a73939a14f5fe1b4 | awan_depan_bawah.png |
| 1523c2b38a047af2878e9c05d8ebb51154f7961eaccf605f7d7384d4f3f03785 | awan_palingdepan_bawah.png |
| 74a51a4366e098f815b2f598f006c76ac2ac82efb708b438fa68fdd73919b580 | background_splashscreen.png |
| e7c3b3bdd90bb52b64e10c1aa535d28715e9381cc2a30ab4cde6c739890c28a6 | candi.png |
| 1b886ef74115e626d0250b66d92557b493bbd0ecd33b48652e3ec2f9fb5175a8 | emblem_astoryaa.png |
| 0a4877e56abe200c06253ce68b9352a24558f893f86da02b9909016384b29e66 | wayang.png |
| a87dfef960c36fc3a9efc9526b4a16d25745c0fab65f9f977115f5319fb384c3 | wordmark.png |
