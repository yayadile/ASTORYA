# pubspec.yaml

Add one line under your existing `flutter: assets:` list (keep every existing AR/audio/video entry). Note the folder is `asset/` (singular):

```yaml
flutter:
  assets:
    # ...existing entries stay as they are...
    - asset/splash_screen/
```

No new packages. The `&` in `asset_rama&sinta.png` is valid on Android and Flutter Web; if it ever causes trouble, rename the file and change the one path in `splash_config.dart`.
