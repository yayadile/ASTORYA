# Navigation (assumptions marked)

`splash_screen.dart` already does `pushReplacement` to `HomeScreen` and honors `ASTORYA_PREVIEW_HOME`.

Assumptions (I did not have your repo):
1. `lib/features/home/home_screen.dart` exports a class `HomeScreen` with a no-argument constructor. If it needs arguments, edit `_goHome()`.
2. `main.dart` uses `home: const SplashScreen()` (or equivalent) inside a `MaterialApp`. The splash needs a `Scaffold`/`MaterialApp` ancestor.
3. If `main.dart` already routes straight to Home when the preview flag is set, that still works; the splash also handles the flag itself.

Minimal `main.dart` wiring if needed:

```dart
import 'features/splash/splash_screen.dart';
// ...
MaterialApp(home: const SplashScreen(), /* existing theme/routes */)
```
The splash never initializes AR or requests camera permission.
